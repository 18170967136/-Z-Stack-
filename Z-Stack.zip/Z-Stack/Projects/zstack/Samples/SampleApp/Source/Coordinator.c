#include "OSAL.h"
#include "ZGlobals.h"
#include "AF.h"
#include "ZDApp.h"
#include "Coordinator.h"
#include "OnBoard.h"
#include "hal_lcd.h"
#include "hal_led.h"
#include "hal_key.h"
const cId_t SampleApp_ClusterList[SAMPLEAPP_MAX_CLUSTERS] =
{
  SAMPLEAPP_PERIODIC_CLUSTERID
};
const SimpleDescriptionFormat_t SampleApp_SimpleDesc =
{
  SAMPLEAPP_ENDPOINT,              //  int Endpoint;
  SAMPLEAPP_PROFID,                //  uint16 AppProfId[2];
  SAMPLEAPP_DEVICEID,              //  uint16 AppDeviceId[2];
  SAMPLEAPP_DEVICE_VERSION,        //  int   AppDevVer:4;
  SAMPLEAPP_FLAGS,                 //  int   AppFlags:4;
  SAMPLEAPP_MAX_CLUSTERS,          //  uint8  AppNumInClusters;
  (cId_t *)SampleApp_ClusterList,  //  uint8 *pAppInClusterList;
  0,          
  (cId_t *)NULL  
};
endPointDesc_t SampleApp_epDesc;
uint8 SampleApp_TaskID;  
uint8 SampleApp_TransID; 

devStates_t SampleApp_NwkState;
void SampleApp_SendPeriodicMessage( afIncomingMSGPacket_t *pkt );
void SampleApp_MessageMSGCB( afIncomingMSGPacket_t *pckt );

void SampleApp_Init( uint8 task_id )
{
  SampleApp_TaskID = task_id;
  SampleApp_NwkState = DEV_INIT;
  SampleApp_TransID = 0;
  
  SampleApp_epDesc.endPoint = SAMPLEAPP_ENDPOINT;
  SampleApp_epDesc.task_id = &SampleApp_TaskID;
  SampleApp_epDesc.simpleDesc
            = (SimpleDescriptionFormat_t *)&SampleApp_SimpleDesc;
  SampleApp_epDesc.latencyReq = noLatencyReqs;
  afRegister( &SampleApp_epDesc );
}

uint16 SampleApp_ProcessEvent( uint8 task_id, uint16 events )
{
  afIncomingMSGPacket_t *MSGpkt;

  if ( events & SYS_EVENT_MSG )
  {
    MSGpkt = (afIncomingMSGPacket_t *)osal_msg_receive( SampleApp_TaskID );
    while ( MSGpkt )
    {
      switch ( MSGpkt->hdr.event )
      {
        case AF_INCOMING_MSG_CMD:
          SampleApp_MessageMSGCB( MSGpkt );   //�źŴ���
          

           SampleApp_SendPeriodicMessage(MSGpkt);  //�����ź�
          

          break;        
        default:
          break;
      }
      osal_msg_deallocate( (uint8 *)MSGpkt );
      MSGpkt = (afIncomingMSGPacket_t *)osal_msg_receive( SampleApp_TaskID );
    }
    return (events ^ SYS_EVENT_MSG);
  }
  return 0;
}

void SampleApp_MessageMSGCB( afIncomingMSGPacket_t *pkt )
{
  unsigned char buffer[6]="";

  switch ( pkt->clusterId )
  {
    case SAMPLEAPP_PERIODIC_CLUSTERID:
      osal_memcpy(buffer,pkt->cmd.Data,6);
      if((buffer[0]=='N')&&(buffer[1]=='E')&&(buffer[2]=='W')&&(buffer[3]=='L')&&(buffer[4]=='a')&&(buffer[5]=='b'))
      {
        HalLedBlink(HAL_LED_3,0,50,500);
      }
      else{
         HalLedSet(HAL_LED_2,HAL_LED_MODE_ON);
      }
      break;
  }
}
void SampleApp_SendPeriodicMessage( afIncomingMSGPacket_t *pkt )
{
  unsigned char theMesageData[6] = "HELLO1";
  afAddrType_t my_DstAddr;
  my_DstAddr.addrMode = (afAddrMode_t)Addr16Bit;
  my_DstAddr.endPoint = SAMPLEAPP_ENDPOINT;
  my_DstAddr.addr.shortAddr = pkt->srcAddr.addr.shortAddr;
  AF_DataRequest( &my_DstAddr, 
                  &SampleApp_epDesc,
                  SAMPLEAPP_PERIODIC_CLUSTERID,
                  6,
                  theMesageData,
                  &SampleApp_TransID,
                  AF_DISCV_ROUTE,
                  AF_DEFAULT_RADIUS );
  
  HalLedBlink(HAL_LED_2,0,50,100); 
}